import numpy as np
from time import sleep
# Creation d'un tableau numpy
arr = np.array([1, 2, 3, 4, 5])

# Affichage du tableau
print("Tableau numpy:", arr)

# Affichage de la version de numpy
print("Version de numpy:", np.__version__)

#sleep(10000)






